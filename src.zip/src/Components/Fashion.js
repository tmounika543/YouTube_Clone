import React from 'react';
import { GiHanger } from "react-icons/gi";
import { emptyPageContainer, emptyIconStyle, emptyTextStyle } from './Styles/EmptyPageStyle';
export default function Fashion() {
    return (
        <div style={{ textAlign: 'center', margin: "200px 0px 200px 500px", fontSize: '24px', color: '#555' }}>
            <GiHanger size={80} color="#999" />
            <p>No fashion & beauty content found</p>
        </div>
    );
}
